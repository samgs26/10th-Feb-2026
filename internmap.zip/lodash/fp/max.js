var convert = require('./convert'),
    func = convert('max', require('../max'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
