var convert = require('./convert'),
    func = convert('last', require('../last'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
