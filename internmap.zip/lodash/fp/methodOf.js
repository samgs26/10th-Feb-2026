var convert = require('./convert'),
    func = convert('methodOf', require('../methodOf'));

func.placeholder = require('./placeholder');
module.exports = func;
