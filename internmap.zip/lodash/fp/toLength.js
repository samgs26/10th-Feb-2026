var convert = require('./convert'),
    func = convert('toLength', require('../toLength'), require('./_falseOptions'));

func.placeholder = require('./placeholder');
module.exports = func;
