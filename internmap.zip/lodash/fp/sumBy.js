var convert = require('./convert'),
    func = convert('sumBy', require('../sumBy'));

func.placeholder = require('./placeholder');
module.exports = func;
