module.exports = require('./isMatch');
