# HR RAG AI Chatbot Application

A comprehensive HR management system with a multi-agent AI architecture, real-time CRUD operations, and RAG-based document analysis.

## Project Structure
- **/Backend**: FastAPI server with LangChain RAG engine and specialized HR agents.
- **/Frontend**: Vite + React dashboard with real-time tabular views and role-based access.

## Key Features
- **Multi-Agent Architecture**: Specialized agents for Onboarding, Offboarding, Invoices, Variance, Policy, and Onboarding Docs.
- **Dynamic CRUD**: Add, Retrieve, and Delete records via the dashboard or directly through natural language chat.
- **RAG Support**: Index and query over PDF, TXT, and now DOCX documents.
- **Role-Based Access**: Specialized views and capabilities for Admin vs General User.
- **Email Integration**: Share reports directly from the dashboard.

## Getting Started

### 1. Backend Setup
```bash
cd Backend
pip install -r requirements.txt
python main.py
```
*Requires an OpenAI API key in `.env`.*

### 2. Frontend Setup
```bash
cd Frontend
npm install
npm run dev
```

### 3. Usage
- Log in as **Admin** to perform CRUD operations and deep data analysis.
- Log in as **User** for read-only reports and policy queries.
- Use the **AI Assistant** in each section for category-specific help.
