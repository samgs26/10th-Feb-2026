import os
from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage

load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")
print(f"Testing key: {api_key[:10]}...")

llm = ChatOpenAI(
    model="google/gemini-2.0-flash-001",
    openai_api_key=api_key,
    base_url="https://openrouter.ai/api/v1"
)

try:
    print("Sending test message...")
    response = llm.invoke([HumanMessage(content="Hello")])
    print(f"Response: {response.content}")
except Exception as e:
    print(f"Error: {e}")
    import traceback
    traceback.print_exc()
