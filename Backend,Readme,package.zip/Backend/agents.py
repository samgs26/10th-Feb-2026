from typing import List, Optional, Dict, Any
import os
import json
from langchain_openai import ChatOpenAI
from langchain_core.messages import SystemMessage, HumanMessage
from langchain.tools import tool
from rag_engine import RAGEngine
from data_manager import DataManager

# Initialize DataManager globally for easy access by tools
base_data_dir = os.getenv("BASE_DATA_DIR")
data_manager = DataManager(base_data_dir=base_data_dir)

@tool
def get_hr_records(category: str) -> str:
    """Useful for retrieving all records for a specific HR category. 
    Categories include: onboarding, offboarding, invoice, variance, policy, newOnboardingDocs."""
    records = data_manager.get_records(category)
    def json_serial(obj):
        if isinstance(obj, (pd.Timestamp, pd.DatetimeIndex)):
            return obj.isoformat()
        return str(obj)
    return json.dumps(records, indent=2, default=json_serial)

@tool
def add_hr_record(category: str, record_json: str) -> str:
    """Useful for adding a new record to a specific HR category.
    The record must be a valid JSON string representing the object to add."""
    try:
        record = json.loads(record_json)
        data_manager.add_record(category, record)
        return f"Successfully added record to {category}."
    except Exception as e:
        return f"Error adding record: {str(e)}"

@tool
def delete_hr_record(category: str, lookup_field: str, lookup_value: str) -> str:
    """Useful for deleting a record from a specific HR category based on a field and value (e.g., id or invoiceNumber)."""
    try:
        data_manager.delete_record(category, lookup_field, lookup_value)
        return f"Successfully deleted record from {category} where {lookup_field} = {lookup_value}."
    except Exception as e:
        return f"Error deleting record: {str(e)}"

class BaseHRChain:
    def __init__(self, rag_engine: RAGEngine, category: str):
        api_key = os.getenv("OPENAI_API_KEY")
        self.llm = ChatOpenAI(
            model="google/gemini-2.0-flash-001",
            temperature=0.2, # Lower temperature for data operations
            openai_api_key=api_key, 
            base_url="https://openrouter.ai/api/v1",
            model_kwargs={"extra_headers": {"HTTP-Referer": "https://localhost"}}
        )
        self.rag_engine = rag_engine
        self.category = category
        self.tools = [get_hr_records, add_hr_record, delete_hr_record]
        self.llm_with_tools = self.llm.bind_tools(self.tools)

    def get_context(self, query: str) -> str:
        docs = self.rag_engine.query(query)
        return "\n\n".join([d.page_content for d in docs])

    def chat(self, query: str) -> str:
        context = self.get_context(query)
        records = data_manager.get_records(self.category)
        
        system_prompt = (
            f"You are the specialized HR AI Agent for the '{self.category}' section. "
            "You have access to both unstructured documents (via RAG) and structured records (via tools). "
            "Your goal is to help users manage, analyze, and update records in this section.\n"
            "Rules:\n"
            "1. ALWAYS check the current records using 'get_hr_records' if the user asks for data or wants to modify it.\n"
            "2. Use 'add_hr_record' to create new entries. Ensure all required fields are provided. If fields are missing, ask the user.\n"
            "3. Use 'delete_hr_record' to remove entries when requested.\n"
            "4. For general questions, use the RAG context provided below.\n"
            "5. Provide detailed analysis, calculations, and clear markdown tables for data comparisons.\n"
            f"Current category: {self.category}\n"
            f"Context from documents (RAG): {context}\n"
            f"Current records snapshot: {json.dumps(records)[:1000]}..."
        )
        
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=query)
        ]
        
        response = self.llm_with_tools.invoke(messages)
        
        # Handle tool calls
        if response.tool_calls:
            # For simplicity in this implementation, we'll execute tools and return a final consolidated response
            # In a full-blown agent, we'd loop until the model is satisfied.
            tool_outputs = []
            for tool_call in response.tool_calls:
                t_name = tool_call["name"]
                t_args = tool_call["args"]
                if t_name == "get_hr_records":
                    tool_outputs.append(get_hr_records.invoke(t_args))
                elif t_name == "add_hr_record":
                    tool_outputs.append(add_hr_record.invoke(t_args))
                elif t_name == "delete_hr_record":
                    tool_outputs.append(delete_hr_record.invoke(t_args))
            
            # Follow up with the model to give the final answer
            messages.append(response)
            for i, output in enumerate(tool_outputs):
                 messages.append(HumanMessage(content=f"Tool output ({i+1}): {output}"))
            
            final_response = self.llm.invoke(messages)
            return final_response.content
            
        return response.content

# Specialized Agents
class OnboardingAgent(BaseHRChain):
    def __init__(self, rag_engine: RAGEngine):
        super().__init__(rag_engine, "onboarding")

class OffboardingAgent(BaseHRChain):
    def __init__(self, rag_engine: RAGEngine):
        super().__init__(rag_engine, "offboarding")

class InvoiceAgent(BaseHRChain):
    def __init__(self, rag_engine: RAGEngine):
        super().__init__(rag_engine, "invoice")

class VarianceAgent(BaseHRChain):
    def __init__(self, rag_engine: RAGEngine):
        super().__init__(rag_engine, "variance")

class PolicyAgent(BaseHRChain):
    def __init__(self, rag_engine: RAGEngine):
        super().__init__(rag_engine, "policy")

class NewOnboardingDocsAgent(BaseHRChain):
    def __init__(self, rag_engine: RAGEngine):
        super().__init__(rag_engine, "newOnboardingDocs")

class AdminAgent(BaseHRChain): # Fallback/General Admin
    def __init__(self, rag_engine: RAGEngine):
        super().__init__(rag_engine, "general")
    def chat(self, query: str, mock_data: dict = None) -> str:
        # For general admin, route to specific logic if needed, or just use base behavior
        return super().chat(query)

class UserAgent(BaseHRChain): # Fallback/General User
    def __init__(self, rag_engine: RAGEngine):
        super().__init__(rag_engine, "general")
