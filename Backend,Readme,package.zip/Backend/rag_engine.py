import os
from typing import List
from langchain_community.document_loaders import PyPDFLoader, TextLoader, Docx2txtLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
import pandas as pd

class RAGEngine:
    def __init__(self, index_path=None):
        self.index_path = index_path or os.getenv("INDEX_PATH", "faiss_index")
        api_key = os.getenv("OPENAI_API_KEY")
        # For OpenRouter, we should provide the base_url and potentially a specific model
        self.embeddings = OpenAIEmbeddings(
            openai_api_key=api_key,
            base_url="https://openrouter.ai/api/v1",
            model="openai/text-embedding-3-small" # Common embedding model on OpenRouter
        )
        self.vector_store = None
        self.load_index()

    def load_index(self):
        if os.path.exists(self.index_path):
            self.vector_store = FAISS.load_local(self.index_path, self.embeddings, allow_dangerous_deserialization=True)
            print("Loaded existing FAISS index.")
        else:
            print("No existing FAISS index found.")

    def add_documents(self, file_path: str):
        full_text = ""
        preview_data = None
        columns = None
        
        try:
            if file_path.endswith('.pdf'):
                loader = PyPDFLoader(file_path)
                docs = loader.load()
                full_text = "\n".join([doc.page_content for doc in docs])
                text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
                chunks = text_splitter.split_documents(docs)
                num_items = len(chunks)
                indexing_items = chunks
            elif file_path.endswith('.txt'):
                loader = TextLoader(file_path)
                docs = loader.load()
                full_text = "\n".join([doc.page_content for doc in docs])
                text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
                chunks = text_splitter.split_documents(docs)
                num_items = len(chunks)
                indexing_items = chunks
            elif file_path.endswith('.docx'):
                loader = Docx2txtLoader(file_path)
                docs = loader.load()
                full_text = "\n".join([doc.page_content for doc in docs])
                text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
                chunks = text_splitter.split_documents(docs)
                num_items = len(chunks)
                indexing_items = chunks
            elif file_path.endswith(('.xlsx', '.xls')):
                df = pd.read_excel(file_path)
                # Ensure no problematic types in preview_data
                records = df.head(10).to_dict(orient='records')
                preview_data = []
                for r in records:
                    clean_r = {}
                    for k, v in r.items():
                        if pd.isna(v):
                            clean_r[k] = None
                        elif isinstance(v, (pd.Timestamp, pd.DatetimeIndex)):
                            clean_r[k] = v.isoformat()
                        else:
                            clean_r[k] = v
                    preview_data.append(clean_r)
                columns = df.columns.tolist()
                documents = []
                full_text_list = []
                for _, row in df.iterrows():
                    content = ", ".join([f"{col}: {val}" for col, val in row.items() if pd.notna(val)])
                    documents.append(Document(page_content=content, metadata={"source": file_path, "type": "excel_row"}))
                    full_text_list.append(content)
                full_text = "\n".join(full_text_list)
                num_items = len(documents)
                indexing_items = documents
            else:
                raise ValueError(f"Unsupported file type: {file_path}")

            # Now attempt indexing
            try:
                if self.vector_store:
                    self.vector_store.add_documents(indexing_items)
                else:
                    self.vector_store = FAISS.from_documents(indexing_items, self.embeddings)
                self.vector_store.save_local(self.index_path)
            except Exception as e:
                print(f"Indexing error: {e}. Returning extracted text regardless.")
                # We don't re-raise here, we want to return what we extracted

            return num_items, preview_data, columns, full_text

        except Exception as outer_e:
            print(f"Extraction error: {outer_e}")
            raise outer_e

    def query(self, text: str, k: int = 4) -> List[Document]:
        if not self.vector_store:
            return []
        return self.vector_store.similarity_search(text, k=k)
