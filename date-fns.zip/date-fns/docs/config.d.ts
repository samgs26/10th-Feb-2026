import type { DateFnsDocs } from "@date-fns/docs";
export declare const config: DateFnsDocs.Config;
