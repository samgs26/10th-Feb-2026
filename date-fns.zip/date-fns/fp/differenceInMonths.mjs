// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { differenceInMonths as fn } from "../differenceInMonths.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const differenceInMonths = convertToFP(fn, 2);

// Fallback for modularized imports:
export default differenceInMonths;
