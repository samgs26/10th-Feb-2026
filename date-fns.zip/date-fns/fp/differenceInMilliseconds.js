"use strict";
exports.differenceInMilliseconds = void 0;

var _index = require("../differenceInMilliseconds.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const differenceInMilliseconds = (exports.differenceInMilliseconds = (0,
_index2.convertToFP)(_index.differenceInMilliseconds, 2));
