// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { formatISODuration as fn } from "../formatISODuration.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const formatISODuration = convertToFP(fn, 1);

// Fallback for modularized imports:
export default formatISODuration;
