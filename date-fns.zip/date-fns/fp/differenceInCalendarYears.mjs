// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { differenceInCalendarYears as fn } from "../differenceInCalendarYears.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const differenceInCalendarYears = convertToFP(fn, 2);

// Fallback for modularized imports:
export default differenceInCalendarYears;
