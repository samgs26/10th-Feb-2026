export declare const eachMonthOfIntervalWithOptions: import("./types.js").FPFn2<
  Date[],
  import("../eachMonthOfInterval.js").EachMonthOfIntervalOptions | undefined,
  import("../fp.js").Interval<Date>
>;
