// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { endOfISOWeek as fn } from "../endOfISOWeek.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const endOfISOWeek = convertToFP(fn, 1);

// Fallback for modularized imports:
export default endOfISOWeek;
