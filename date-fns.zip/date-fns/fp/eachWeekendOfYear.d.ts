export declare const eachWeekendOfYear: import("./types.js").FPFn1<
  Date[],
  string | number | Date
>;
