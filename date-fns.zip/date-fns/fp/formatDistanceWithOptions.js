"use strict";
exports.formatDistanceWithOptions = void 0;

var _index = require("../formatDistance.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const formatDistanceWithOptions = (exports.formatDistanceWithOptions = (0,
_index2.convertToFP)(_index.formatDistance, 3));
