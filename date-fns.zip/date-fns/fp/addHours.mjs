// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { addHours as fn } from "../addHours.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const addHours = convertToFP(fn, 2);

// Fallback for modularized imports:
export default addHours;
