export declare const formatISO9075WithOptions: import("./types.js").FPFn2<
  string,
  import("../formatISO9075.js").FormatISO9075Options | undefined,
  string | number | Date
>;
