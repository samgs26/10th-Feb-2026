export declare const endOfYear: import("./types.js").FPFn1<
  Date,
  string | number | Date
>;
