"use strict";
exports.constructFrom = void 0;

var _index = require("../constructFrom.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const constructFrom = (exports.constructFrom = (0, _index2.convertToFP)(
  _index.constructFrom,
  2,
));
