"use strict";
exports.eachHourOfInterval = void 0;

var _index = require("../eachHourOfInterval.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const eachHourOfInterval = (exports.eachHourOfInterval = (0,
_index2.convertToFP)(_index.eachHourOfInterval, 1));
