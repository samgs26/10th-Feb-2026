export declare const endOfISOWeek: import("./types.js").FPFn1<
  Date,
  string | number | Date
>;
