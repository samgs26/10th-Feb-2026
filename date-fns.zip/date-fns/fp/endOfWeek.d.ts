export declare const endOfWeek: import("./types.js").FPFn1<
  Date,
  string | number | Date
>;
