// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { differenceInMilliseconds as fn } from "../differenceInMilliseconds.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const differenceInMilliseconds = convertToFP(fn, 2);

// Fallback for modularized imports:
export default differenceInMilliseconds;
