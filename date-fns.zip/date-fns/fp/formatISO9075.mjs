// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { formatISO9075 as fn } from "../formatISO9075.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const formatISO9075 = convertToFP(fn, 1);

// Fallback for modularized imports:
export default formatISO9075;
