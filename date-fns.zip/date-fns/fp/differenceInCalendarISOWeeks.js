"use strict";
exports.differenceInCalendarISOWeeks = void 0;

var _index = require("../differenceInCalendarISOWeeks.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const differenceInCalendarISOWeeks = (exports.differenceInCalendarISOWeeks = (0,
_index2.convertToFP)(_index.differenceInCalendarISOWeeks, 2));
