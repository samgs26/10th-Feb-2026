export declare const differenceInMilliseconds: import("./types.js").FPFn2<
  number,
  string | number | Date,
  string | number | Date
>;
