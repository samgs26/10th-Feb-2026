// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { differenceInQuarters as fn } from "../differenceInQuarters.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const differenceInQuartersWithOptions = convertToFP(fn, 3);

// Fallback for modularized imports:
export default differenceInQuartersWithOptions;
