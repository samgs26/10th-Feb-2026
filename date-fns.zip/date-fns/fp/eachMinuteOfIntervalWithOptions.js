"use strict";
exports.eachMinuteOfIntervalWithOptions = void 0;

var _index = require("../eachMinuteOfInterval.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const eachMinuteOfIntervalWithOptions =
  (exports.eachMinuteOfIntervalWithOptions = (0, _index2.convertToFP)(
    _index.eachMinuteOfInterval,
    2,
  ));
