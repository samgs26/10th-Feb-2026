// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { eachWeekOfInterval as fn } from "../eachWeekOfInterval.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const eachWeekOfIntervalWithOptions = convertToFP(fn, 2);

// Fallback for modularized imports:
export default eachWeekOfIntervalWithOptions;
