// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { areIntervalsOverlapping as fn } from "../areIntervalsOverlapping.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const areIntervalsOverlapping = convertToFP(fn, 2);

// Fallback for modularized imports:
export default areIntervalsOverlapping;
