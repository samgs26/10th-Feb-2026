export declare const eachHourOfInterval: import("./types.js").FPFn1<
  Date[],
  import("../fp.js").Interval<Date>
>;
