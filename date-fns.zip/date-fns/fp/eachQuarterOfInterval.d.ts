export declare const eachQuarterOfInterval: import("./types.js").FPFn1<
  Date[],
  import("../fp.js").Interval<Date>
>;
