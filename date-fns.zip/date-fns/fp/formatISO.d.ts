export declare const formatISO: import("./types.js").FPFn1<
  string,
  string | number | Date
>;
