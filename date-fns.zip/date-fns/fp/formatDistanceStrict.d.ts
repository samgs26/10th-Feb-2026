export declare const formatDistanceStrict: import("./types.js").FPFn2<
  string,
  string | number | Date,
  string | number | Date
>;
