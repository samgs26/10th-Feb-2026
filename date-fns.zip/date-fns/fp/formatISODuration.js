"use strict";
exports.formatISODuration = void 0;

var _index = require("../formatISODuration.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const formatISODuration = (exports.formatISODuration = (0, _index2.convertToFP)(
  _index.formatISODuration,
  1,
));
