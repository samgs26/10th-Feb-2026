// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { differenceInSeconds as fn } from "../differenceInSeconds.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const differenceInSeconds = convertToFP(fn, 2);

// Fallback for modularized imports:
export default differenceInSeconds;
