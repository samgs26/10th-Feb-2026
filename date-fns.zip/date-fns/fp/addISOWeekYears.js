"use strict";
exports.addISOWeekYears = void 0;

var _index = require("../addISOWeekYears.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const addISOWeekYears = (exports.addISOWeekYears = (0, _index2.convertToFP)(
  _index.addISOWeekYears,
  2,
));
