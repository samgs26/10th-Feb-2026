// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { addWeeks as fn } from "../addWeeks.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const addWeeks = convertToFP(fn, 2);

// Fallback for modularized imports:
export default addWeeks;
