export declare const addQuarters: import("./types.js").FPFn2<
  Date,
  number,
  string | number | Date
>;
