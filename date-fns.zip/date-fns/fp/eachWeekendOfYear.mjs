// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { eachWeekendOfYear as fn } from "../eachWeekendOfYear.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const eachWeekendOfYear = convertToFP(fn, 1);

// Fallback for modularized imports:
export default eachWeekendOfYear;
