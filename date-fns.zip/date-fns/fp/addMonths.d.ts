export declare const addMonths: import("./types.js").FPFn2<
  Date,
  number,
  string | number | Date
>;
