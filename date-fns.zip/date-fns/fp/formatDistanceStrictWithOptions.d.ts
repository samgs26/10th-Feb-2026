export declare const formatDistanceStrictWithOptions: import("./types.js").FPFn3<
  string,
  import("../formatDistanceStrict.js").FormatDistanceStrictOptions | undefined,
  string | number | Date,
  string | number | Date
>;
