export declare const eachWeekOfIntervalWithOptions: import("./types.js").FPFn2<
  Date[],
  import("../eachWeekOfInterval.js").EachWeekOfIntervalOptions | undefined,
  import("../fp.js").Interval<Date>
>;
