export declare const formatDurationWithOptions: import("./types.js").FPFn2<
  string,
  import("../formatDuration.js").FormatDurationOptions | undefined,
  import("../fp.js").Duration
>;
