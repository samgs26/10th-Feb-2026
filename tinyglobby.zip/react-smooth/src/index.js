import Animate from './Animate';
import { configBezier, configSpring } from './easing';
import AnimateGroup from './AnimateGroup';

export { configSpring, configBezier, AnimateGroup };

export default Animate;
