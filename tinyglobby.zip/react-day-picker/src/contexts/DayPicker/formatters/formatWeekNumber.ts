/**
 * The default formatter for the week number.
 */
export function formatWeekNumber(weekNumber: number): string {
  return `${weekNumber}`;
}
