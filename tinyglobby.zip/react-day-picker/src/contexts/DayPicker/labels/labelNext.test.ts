import { labelNext } from './labelNext';

test('should return the label', () => {
  expect(labelNext()).toEqual('Go to next month');
});
