/**
 * The default ARIA label for the WeekNumber element.
 */
export const labelYearDropdown = (): string => {
  return 'Year: ';
};
