import { labelPrevious } from './labelPrevious';

test('should return the label', () => {
  expect(labelPrevious()).toEqual('Go to previous month');
});
