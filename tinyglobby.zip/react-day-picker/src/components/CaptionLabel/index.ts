export * from './CaptionLabel';
