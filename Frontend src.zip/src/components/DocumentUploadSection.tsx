import { useState, useRef } from 'react';
import { ChevronDown, ChevronUp, Upload, File, X, CheckCircle, Table as TableIcon } from 'lucide-react';
import { uploadDocument } from '../services/api';

interface DocumentUploadSectionProps {
  category: string;
  onUploadSuccess?: () => void;
}

export function DocumentUploadSection({ category, onUploadSuccess }: DocumentUploadSectionProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [uploadStatus, setUploadStatus] = useState<'idle' | 'uploading' | 'success'>('idle');
  const [previews, setPreviews] = useState<{ filename: string; columns: string[]; data: any[] }[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      setUploadedFiles([...uploadedFiles, ...newFiles]);
    }
  };

  const removeFile = (index: number) => {
    setUploadedFiles(uploadedFiles.filter((_, i) => i !== index));
  };

  const handleUpload = async () => {
    if (uploadedFiles.length === 0) return;

    setUploadStatus('uploading');
    const newPreviews: any[] = [];

    try {
      for (const file of uploadedFiles) {
        const result = await uploadDocument(file, category);
        if (result.preview) {
          newPreviews.push({
            filename: file.name,
            columns: result.columns,
            data: result.preview
          });
        }
      }

      setPreviews([...previews, ...newPreviews]);
      setUploadStatus('success');

      if (onUploadSuccess) {
        onUploadSuccess();
      }

      setTimeout(() => {
        setUploadStatus('idle');
        setUploadedFiles([]);
      }, 2000);
    } catch (error) {
      console.error('Upload failed:', error);
      alert('Upload failed. Please ensure the backend is running.');
      setUploadStatus('idle');
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  return (
    <div className="border-2 border-teal-200 rounded-xl overflow-hidden bg-white shadow-md">
      <button
        onClick={() => setIsExpanded(!isExpanded)}
        className="w-full flex items-center justify-between px-5 py-4 bg-gradient-to-r from-teal-50 to-blue-50 hover:from-teal-100 hover:to-blue-100 transition-all"
      >
        <div className="flex items-center gap-3">
          <div className="p-2 bg-teal-600 rounded-lg">
            <Upload className="size-5 text-white" />
          </div>
          <div className="text-left">
            <h3 className="font-bold text-teal-700">Upload Documents</h3>
            <p className="text-xs text-teal-600">Upload files for {category}</p>
          </div>
        </div>
        {isExpanded ? (
          <ChevronUp className="size-5 text-teal-600" />
        ) : (
          <ChevronDown className="size-5 text-teal-600" />
        )}
      </button>

      {isExpanded && (
        <div className="p-5 border-t-2 border-teal-100">
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileSelect}
            multiple
            className="hidden"
          />

          {/* Upload Area */}
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-teal-300 rounded-xl p-8 text-center cursor-pointer hover:border-teal-500 hover:bg-teal-50/50 transition-all"
          >
            <div className="flex flex-col items-center gap-3">
              <div className="p-4 bg-teal-100 rounded-full">
                <Upload className="size-8 text-teal-600" />
              </div>
              <div>
                <p className="font-semibold text-gray-700">Click to upload documents</p>
                <p className="text-sm text-gray-500 mt-1">or drag and drop files here</p>
              </div>
              <p className="text-xs text-gray-400">PDF, DOC, DOCX, XLS, XLSX, PNG, JPG (Max 10MB)</p>
            </div>
          </div>

          {/* Uploaded Files List */}
          {(uploadedFiles.length > 0) && (
            <div className="mt-4 space-y-2">
              <p className="text-sm font-semibold text-gray-700 mb-2">Selected Files ({uploadedFiles.length})</p>
              {uploadedFiles.map((file, index) => (
                <div key={index} className="flex items-center justify-between bg-gradient-to-r from-teal-50 to-blue-50 rounded-lg px-4 py-3 border border-teal-200">
                  <div className="flex items-center gap-3">
                    <File className="size-5 text-teal-600" />
                    <div>
                      <p className="text-sm font-medium text-gray-700">{file.name}</p>
                      <p className="text-xs text-gray-500">{formatFileSize(file.size)}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => removeFile(index)}
                    className="p-1.5 hover:bg-red-100 rounded-lg transition-colors"
                  >
                    <X className="size-4 text-red-500" />
                  </button>
                </div>
              ))}

              <button
                onClick={handleUpload}
                disabled={uploadStatus !== 'idle'}
                className="w-full mt-4 flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-teal-600 to-blue-600 text-white rounded-lg hover:from-teal-700 hover:to-blue-700 transition-all font-semibold shadow-lg disabled:opacity-50"
              >
                {uploadStatus === 'uploading' && (
                  <>
                    <div className="size-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Uploading...
                  </>
                )}
                {uploadStatus === 'success' && (
                  <>
                    <CheckCircle className="size-5" />
                    Uploaded Successfully!
                  </>
                )}
                {uploadStatus === 'idle' && (
                  <>
                    <Upload className="size-5" />
                    Upload Files
                  </>
                )}
              </button>
            </div>
          )}

          {/* Table Preview Section */}
          {previews.length > 0 && (
            <div className="mt-8 space-y-6">
              <h4 className="font-bold text-teal-800 flex items-center gap-2">
                <TableIcon className="size-5" />
                Table Details from Uploaded Files
              </h4>
              {previews.map((preview, pIdx) => (
                <div key={pIdx} className="border border-teal-100 rounded-xl overflow-hidden shadow-sm">
                  <div className="bg-teal-50 px-4 py-2 border-b border-teal-100 flex justify-between items-center">
                    <span className="text-sm font-semibold text-teal-700">{preview.filename} (Preview)</span>
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left">
                      <thead className="bg-white text-gray-600 uppercase text-xs font-bold border-b border-teal-50">
                        <tr>
                          {preview.columns.map((col, cIdx) => (
                            <th key={cIdx} className="px-4 py-3">{col}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-teal-50">
                        {preview.data.map((row, rIdx) => (
                          <tr key={rIdx} className="hover:bg-teal-50/30 transition-colors">
                            {preview.columns.map((col, cIdx) => (
                              <td key={cIdx} className="px-4 py-3 text-gray-700 whitespace-nowrap">
                                {String(row[col] ?? '')}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
