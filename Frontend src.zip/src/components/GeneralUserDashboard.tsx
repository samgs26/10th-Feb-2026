import { useState, useRef, useEffect } from 'react';
import { LogOut, ChevronRight, ChevronDown, Paperclip, Square, Mic, Send, X, File, MessageSquare, Menu, Table } from 'lucide-react';
import { DocumentUploadSection } from './DocumentUploadSection';
import { EmailReportSection } from './EmailReportSection';
import { UserDataViewer } from './UserDataViewer';
import { PolicyDetailView } from './PolicyDetailView';
import { chatWithAI, uploadDocument } from '../services/api';

interface GeneralUserDashboardProps {
  onLogout: () => void;
}

type MenuItemType = 'onboarding' | 'offboarding' | 'invoice' | 'variance' | 'policy' | 'newOnboardingDocs';

const menuItems: { id: MenuItemType; label: string; subItems: string[] }[] = [
  { id: 'onboarding', label: 'Onboarding', subItems: ['Employee Onboarding'] },
  { id: 'offboarding', label: 'Offboarding', subItems: ['Offboarding Details'] },
  { id: 'invoice', label: 'Invoice', subItems: ['Create Invoice'] },
  { id: 'variance', label: 'Variance', subItems: ['Budget Variance'] },
  { id: 'policy', label: 'Policy', subItems: ['HR Policies', 'IT Policies', 'Security Policies'] },
  { id: 'newOnboardingDocs', label: 'New Onboarding Documents', subItems: ['Onboardee Documents'] },
];

interface ChatMessage {
  id: number;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  attachments?: { name: string; size: number; type: string }[];
  isVoice?: boolean;
}

export function GeneralUserDashboard({ onLogout }: GeneralUserDashboardProps) {
  const [expandedItems, setExpandedItems] = useState<Set<MenuItemType>>(new Set());
  const [selectedItem, setSelectedItem] = useState<string | null>(null);
  const [currentCategory, setCurrentCategory] = useState<MenuItemType | null>(null);
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: 1,
      text: "Hello! I'm here to help you with your queries. How can I assist you today?",
      sender: 'bot',
      timestamp: new Date(),
    },
  ]);
  const [inputMessage, setInputMessage] = useState('');
  const [attachedFiles, setAttachedFiles] = useState<File[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [recordingTime, setRecordingTime] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recordingIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const [lastUploadedPolicyContent, setLastUploadedPolicyContent] = useState<string | null>(null);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  const handleRefresh = () => {
    setRefreshTrigger(prev => prev + 1);
  };

  const toggleItem = (itemId: MenuItemType) => {
    const newExpanded = new Set(expandedItems);
    if (newExpanded.has(itemId)) {
      newExpanded.delete(itemId);
    } else {
      newExpanded.add(itemId);
      setCurrentCategory(itemId); // Automatically switch to this category agent
      setSelectedItem(null); // Clear sub-item when switching main category
    }
    setExpandedItems(newExpanded);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      setAttachedFiles([...attachedFiles, ...newFiles]);
    }
  };

  const removeAttachment = (index: number) => {
    setAttachedFiles(attachedFiles.filter((_, i) => i !== index));
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  const handleSendMessage = async () => {
    if (!inputMessage.trim() && attachedFiles.length === 0) return;

    const userMessageText = inputMessage || (attachedFiles.length > 0 ? `📎 Sent ${attachedFiles.length} attachment(s)` : '');

    const newMessage: ChatMessage = {
      id: Date.now(),
      text: userMessageText,
      sender: 'user',
      timestamp: new Date(),
      attachments: attachedFiles.map(f => ({
        name: f.name,
        size: f.size,
        type: f.type
      })),
    };

    setChatMessages(prev => [...prev, newMessage]);
    const messageToSend = userMessageText;
    setInputMessage('');

    // Process attachments for RAG
    if (attachedFiles.length > 0) {
      for (const file of attachedFiles) {
        try {
          const result = await uploadDocument(file, currentCategory || undefined);
          if (result.full_text) {
            setLastUploadedPolicyContent(result.full_text);
          }
        } catch (error) {
          console.error(`Error uploading ${file.name}:`, error);
        }
      }
      handleRefresh();
    }

    setAttachedFiles([]);

    // Call Backend API
    try {
      // Route query to specialized agent if a category is selected
      const aiResponse = await chatWithAI(messageToSend, 'user', currentCategory || undefined);
      const botResponse: ChatMessage = {
        id: Date.now() + 1,
        text: aiResponse,
        sender: 'bot',
        timestamp: new Date(),
      };
      setChatMessages((prev) => [...prev, botResponse]);

      // If AI response suggests a record was added/updated, trigger refresh
      if (aiResponse.toLowerCase().includes('added') || aiResponse.toLowerCase().includes('updated') || aiResponse.toLowerCase().includes('deleted')) {
        handleRefresh();
      }
    } catch (error: any) {
      const errorMsg = error.response?.data?.detail || "Error connecting to AI service. Please ensure the backend is running.";
      setChatMessages(prev => [...prev, {
        id: Date.now() + 1,
        text: typeof errorMsg === 'string' ? errorMsg : JSON.stringify(errorMsg),
        sender: 'bot' as const,
        timestamp: new Date(),
      }]);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      const audioChunks: Blob[] = [];

      mediaRecorder.ondataavailable = (event) => {
        audioChunks.push(event.data);
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
        const duration = recordingTime;

        const newMessage: ChatMessage = {
          id: chatMessages.length + 1,
          text: `🎤 Voice message (${duration}s)`,
          sender: 'user',
          timestamp: new Date(),
          isVoice: true,
        };

        setChatMessages([...chatMessages, newMessage]);

        // Mock bot response for voice
        setTimeout(() => {
          const botResponse: ChatMessage = {
            id: chatMessages.length + 2,
            text: "I've received your voice message. I'm processing your request.",
            sender: 'bot',
            timestamp: new Date(),
          };
          setChatMessages((prev) => [...prev, botResponse]);
        }, 1000);

        setRecordingTime(0);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      setRecordingTime(0);

      recordingIntervalRef.current = setInterval(() => {
        setRecordingTime(prev => prev + 1);
      }, 1000);
    } catch (error) {
      console.error('Error accessing microphone:', error);
      alert('Could not access microphone. Please check permissions.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (recordingIntervalRef.current) {
        clearInterval(recordingIntervalRef.current);
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-teal-50 via-blue-50 to-cyan-100 flex flex-col">
      {/* Header */}
      <header className="bg-gradient-to-r from-teal-600 to-blue-600 shadow-lg px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-white/20 rounded-lg">
              <MessageSquare className="size-6 text-white" />
            </div>
            <div>
              <h1 className="text-2xl text-white font-bold">User Dashboard</h1>
              <p className="text-teal-100 text-sm">Access your resources and AI assistant</p>
            </div>
          </div>
          <button
            onClick={onLogout}
            className="flex items-center gap-2 px-4 py-2 bg-white/10 text-white hover:bg-white/20 rounded-lg transition-all backdrop-blur-sm border border-white/20"
          >
            <LogOut className="size-5" />
            Logout
          </button>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        {/* Left Panel - Accordion Menu */}
        <aside className="w-80 bg-white shadow-lg overflow-y-auto">
          <div className="p-6">
            <div className="mb-6">
              <div className="flex items-center gap-2 text-teal-600 mb-2">
                <Menu className="size-4" />
                <p className="text-xs font-bold uppercase tracking-wider">Navigation Menu</p>
              </div>
              <div className="h-1 w-12 bg-gradient-to-r from-teal-600 to-blue-600 rounded-full"></div>
            </div>
            <div className="space-y-2">
              {menuItems.map((item) => (
                <div key={item.id} className="border border-teal-100 rounded-xl overflow-hidden">
                  <button
                    onClick={() => toggleItem(item.id)}
                    className={`w-full flex items-center justify-between px-4 py-3 transition-all font-medium ${currentCategory === item.id ? 'bg-teal-50' : 'hover:bg-gray-50'}`}
                  >
                    <span className={`${currentCategory === item.id ? 'text-teal-700 font-bold' : 'text-gray-700'}`}>{item.label}</span>
                    <div className={`p-1 rounded-full transition-all ${expandedItems.has(item.id) ? 'bg-teal-100' : 'bg-gray-100'}`}>
                      {expandedItems.has(item.id) ? (
                        <ChevronDown className="size-5 text-teal-600" />
                      ) : (
                        <ChevronRight className="size-5 text-gray-500" />
                      )}
                    </div>
                  </button>

                  {expandedItems.has(item.id) && (
                    <div className="bg-gradient-to-r from-teal-50/50 to-blue-50/50 px-4 pb-3 space-y-1">
                      {item.subItems.map((subItem) => (
                        <button
                          key={subItem}
                          onClick={() => setSelectedItem(subItem)}
                          className={`w-full text-left px-3 py-2.5 rounded-lg text-sm transition-all ${selectedItem === subItem
                            ? 'bg-gradient-to-r from-teal-600 to-blue-600 text-white shadow-lg shadow-teal-500/50 font-medium'
                            : 'text-gray-600 hover:bg-white hover:text-teal-700'
                            }`}
                        >
                          {subItem}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </aside>

        {/* Center Content Area */}
        <main className="flex-1 p-6 overflow-y-auto">
          <div className="bg-white rounded-2xl shadow-xl p-8 border border-teal-100 min-h-full">
            {currentCategory === 'policy' ? (
              <PolicyDetailView
                policyType={selectedItem || 'HR Policies'}
                variant="user"
                externalContent={lastUploadedPolicyContent}
              />
            ) : currentCategory ? (
              <div className="space-y-8">
                <div className="flex items-center gap-3 border-b-2 border-teal-50 pb-4">
                  <div className="p-3 bg-gradient-to-r from-teal-100 to-blue-100 rounded-xl">
                    <Table className="size-6 text-teal-600" />
                  </div>
                  <h2 className="text-2xl font-bold bg-gradient-to-r from-teal-600 to-blue-600 bg-clip-text text-transparent">
                    {menuItems.find(m => m.id === currentCategory)?.label} Report
                  </h2>
                </div>

                {/* Tabular View */}
                <UserDataViewer category={currentCategory} refreshTrigger={refreshTrigger} />

                {/* Specific Sub-item View or Placeholder */}
                {selectedItem && (
                  <div className="bg-teal-50/50 rounded-xl p-6 border border-teal-100 animate-in fade-in slide-in-from-top-2">
                    <h4 className="font-bold text-teal-800 mb-2">{selectedItem}</h4>
                    <p className="text-gray-600 text-sm">Detailed view for {selectedItem} is active.</p>
                  </div>
                )}

                {/* Additional Sections */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-4">
                  <DocumentUploadSection
                    category={selectedItem || currentCategory}
                    onUploadSuccess={handleRefresh}
                  />
                  <EmailReportSection key={currentCategory} category={currentCategory} variant="user" />
                </div>
              </div>
            ) : (
              <div className="text-center py-24">
                <div className="inline-flex p-6 bg-gradient-to-r from-teal-100 to-blue-100 rounded-2xl mb-4">
                  <Menu className="size-12 text-teal-600" />
                </div>
                <p className="text-gray-500 text-lg">Select a category from the menu to analyze data</p>
                <p className="text-gray-400 text-sm mt-2">Specialized AI agents are ready to assist with each section</p>
              </div>
            )}
          </div>
        </main>

        {/* Right Panel - Chatbot */}
        <aside className="w-96 bg-white shadow-lg flex flex-col border-l-2 border-teal-100">
          <div className="px-6 py-5 bg-gradient-to-r from-teal-50 to-blue-50 border-b-2 border-teal-100">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-gradient-to-r from-teal-600 to-blue-600 rounded-lg relative">
                <MessageSquare className="size-5 text-white" />
                {currentCategory && (
                  <div className="absolute -top-1 -right-1 size-3 bg-green-500 rounded-full border-2 border-white animate-pulse" />
                )}
              </div>
              <div>
                <h2 className="text-lg font-bold text-teal-700">
                  {currentCategory ? `${menuItems.find(m => m.id === currentCategory)?.label} Assistant` : 'HR Assistant'}
                </h2>
                <p className="text-xs text-teal-600">
                  {currentCategory ? 'Focused Category Support' : 'Select a category to enable specialized help'}
                </p>
              </div>
            </div>
          </div>

          {/* Chat Messages Area */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-teal-50/30 to-transparent">
            {chatMessages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl px-4 py-3 shadow-md ${message.sender === 'user'
                    ? 'bg-gradient-to-r from-teal-600 to-blue-600 text-white'
                    : 'bg-white text-gray-800 border border-teal-100'
                    }`}
                >
                  <div className="text-sm leading-relaxed prose prose-sm max-w-none">
                    {message.text.split('\n').map((line, i) => <p key={i}>{line}</p>)}
                  </div>
                  {message.attachments && message.attachments.length > 0 && (
                    <div className="mt-2 space-y-1">
                      {message.attachments.map((file, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-xs bg-white/10 rounded-lg px-2 py-1.5">
                          <File className="size-3" />
                          <span>{file.name}</span>
                          <span className="opacity-70">({formatFileSize(file.size)})</span>
                        </div>
                      ))}
                    </div>
                  )}
                  <p
                    className={`text-xs mt-2 ${message.sender === 'user' ? 'text-teal-100' : 'text-gray-500'
                      }`}
                  >
                    {message.timestamp.toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Chat Input Area */}
          <div className="p-4 border-t-2 border-teal-100 bg-white">
            {isRecording && (
              <div className="mb-3 flex items-center gap-2 bg-red-50 text-red-600 px-3 py-2.5 rounded-xl border border-red-200">
                <div className="size-2 bg-red-600 rounded-full animate-pulse" />
                <span className="text-sm font-medium">Recording... {recordingTime}s</span>
              </div>
            )}

            {attachedFiles.length > 0 && (
              <div className="mb-3 space-y-2">
                {attachedFiles.map((file, index) => (
                  <div key={index} className="flex items-center justify-between bg-gradient-to-r from-teal-50 to-blue-50 rounded-xl px-3 py-2.5 border border-teal-200">
                    <div className="flex items-center gap-2 text-sm">
                      <File className="size-4 text-teal-600" />
                      <span className="text-gray-700 font-medium">{file.name}</span>
                      <span className="text-gray-500 text-xs">({formatFileSize(file.size)})</span>
                    </div>
                    <button
                      onClick={() => removeAttachment(index)}
                      className="p-1.5 hover:bg-red-100 rounded-lg transition-colors"
                    >
                      <X className="size-4 text-red-500" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            <div className="flex items-end gap-2">
              <div className="flex-1 border-2 border-teal-200 rounded-xl p-3 focus-within:border-teal-500 transition-all bg-white">
                <textarea
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessage();
                    }
                  }}
                  placeholder={currentCategory ? `Ask the ${menuItems.find(m => m.id === currentCategory)?.label} Assistant...` : "Select a category to start chatting..."}
                  className="w-full resize-none focus:outline-none text-sm"
                  rows={2}
                  disabled={isRecording}
                />
                <div className="flex items-center gap-2 mt-2">
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileSelect}
                    multiple
                    className="hidden"
                  />
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="p-1.5 hover:bg-teal-100 rounded-lg transition-colors group"
                    title="Attach file"
                    disabled={isRecording}
                  >
                    <Paperclip className="size-5 text-teal-600 group-hover:scale-110 transition-transform" />
                  </button>
                  <button
                    onClick={stopRecording}
                    className={`p-1.5 hover:bg-gray-100 rounded-lg transition-colors ${!isRecording ? 'opacity-50 cursor-not-allowed' : ''
                      }`}
                    title="Stop recording"
                    disabled={!isRecording}
                  >
                    <Square className="size-5 text-gray-500" />
                  </button>
                  <button
                    onClick={isRecording ? stopRecording : startRecording}
                    className={`p-1.5 rounded-lg transition-all group ${isRecording ? 'bg-red-100 hover:bg-red-200' : 'hover:bg-teal-100'
                      }`}
                    title={isRecording ? 'Stop recording' : 'Start voice recording'}
                  >
                    <Mic className={`size-5 group-hover:scale-110 transition-transform ${isRecording ? 'text-red-600' : 'text-teal-600'}`} />
                  </button>
                </div>
              </div>
              <button
                onClick={handleSendMessage}
                className="p-3.5 bg-gradient-to-r from-teal-600 to-blue-600 text-white rounded-xl hover:from-teal-700 hover:to-blue-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg hover:shadow-xl transform hover:scale-105"
                title="Send message"
                disabled={isRecording}
              >
                <Send className="size-5" />
              </button>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}