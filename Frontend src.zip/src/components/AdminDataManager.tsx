import { useState, useEffect } from 'react';
import { Plus, X, Download, Loader2 } from 'lucide-react';
import { DataTable } from './DataTable';
import { EmailReportSection } from './EmailReportSection';
import { getRecords, addRecord, deleteRecord } from '../services/api';

interface AdminDataManagerProps {
  initialData?: any[]; // Keep for prop compatibility but prefer fetching
  reportType: string;
  refreshTrigger?: number;
}

export function AdminDataManager({ initialData, reportType, refreshTrigger }: AdminDataManagerProps) {
  const [data, setData] = useState<any[]>(initialData || []);
  const [loading, setLoading] = useState(false);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newRecord, setNewRecord] = useState<any>({});
  const [editingRecord, setEditingRecord] = useState<any>(null);

  const fetchRecords = async () => {
    setLoading(true);
    try {
      const records = await getRecords(reportType);
      setData(records);
    } catch (error) {
      console.error('Failed to fetch records:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRecords();
  }, [reportType, refreshTrigger]);

  const columns = data.length > 0 ? Object.keys(data[0]) : [];

  const handleAddRecord = async () => {
    const recordToAdd = { ...newRecord };

    // Simple id generation if missing
    if (!recordToAdd.id && !recordToAdd.invoiceNumber && !recordToAdd.policyId && !recordToAdd.projectId && !recordToAdd.docId) {
      recordToAdd.id = `NEW-${Date.now()}`;
    }

    try {
      await addRecord(reportType, recordToAdd);
      await fetchRecords();
      setNewRecord({});
      setIsAddModalOpen(false);
    } catch (error) {
      alert('Failed to add record');
    }
  };

  const handleDeleteRecord = async (index: number) => {
    if (confirm('Are you sure you want to delete this record?')) {
      const record = data[index];
      const lookupField = record.id ? 'id' :
        record.invoiceNumber ? 'invoiceNumber' :
          record.policyId ? 'policyId' :
            record.projectId ? 'projectId' :
              record.docId ? 'docId' : null;

      if (!lookupField) {
        alert('Cannot delete record: No unique identifier found');
        return;
      }

      try {
        await deleteRecord(reportType, lookupField, record[lookupField]);
        await fetchRecords();
      } catch (error) {
        alert('Failed to delete record');
      }
    }
  };

  const handleEditRecord = (index: number) => {
    setEditingRecord({ ...data[index], index });
    setIsAddModalOpen(true);
  };

  const handleUpdateRecord = async () => {
    if (editingRecord) {
      const updatedRecord = { ...editingRecord };
      delete updatedRecord.index;

      try {
        // For simplicity, we treat update as delete+add in this backend implementation
        const lookupField = updatedRecord.id ? 'id' :
          updatedRecord.invoiceNumber ? 'invoiceNumber' :
            updatedRecord.policyId ? 'policyId' :
              updatedRecord.projectId ? 'projectId' :
                updatedRecord.docId ? 'docId' : null;

        if (lookupField) {
          await deleteRecord(reportType, lookupField, updatedRecord[lookupField]);
        }
        await addRecord(reportType, updatedRecord);
        await fetchRecords();
        setEditingRecord(null);
        setIsAddModalOpen(false);
      } catch (error) {
        alert('Failed to update record');
      }
    }
  };

  const formatColumnName = (column: string) => {
    return column
      .replace(/([A-Z])/g, ' $1')
      .replace(/^./, (str) => str.toUpperCase())
      .trim();
  };

  const handleExportCSV = () => {
    if (data.length === 0) return;

    const headers = columns.join(',');
    const rows = data.map(row =>
      columns.map(col => {
        const value = row[col];
        if (typeof value === 'string' && (value.includes(',') || value.includes('"'))) {
          return `"${value.replace(/"/g, '""')}"`;
        }
        return value;
      }).join(',')
    );

    const csvContent = [headers, ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `${reportType}_report_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div>
      <div className="mb-6 flex justify-between items-center">
        <div className="flex items-center gap-4">
          <div className="px-4 py-2 bg-gradient-to-r from-purple-100 to-indigo-100 rounded-lg border border-purple-200">
            <p className="text-sm text-purple-700">
              Total Records: <span className="font-bold text-lg">{data.length}</span>
            </p>
          </div>
          {loading && <Loader2 className="size-5 text-purple-600 animate-spin" />}
        </div>
        <div className="flex gap-3">
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-2 px-5 py-2.5 bg-white border-2 border-purple-300 text-purple-700 rounded-lg hover:bg-purple-50 hover:border-purple-400 transition-all font-medium shadow-sm hover:shadow-md"
          >
            <Download className="size-5" />
            Export CSV
          </button>
          <button
            onClick={() => {
              setEditingRecord(null);
              setNewRecord({});
              setIsAddModalOpen(true);
            }}
            className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-lg hover:from-purple-700 hover:to-indigo-700 transition-all font-medium shadow-lg hover:shadow-xl transform hover:scale-105"
          >
            <Plus className="size-5" />
            Add New Record
          </button>
        </div>
      </div>

      <div className="mb-6">
        <EmailReportSection key={reportType} category={reportType} variant="admin" />
      </div>

      <DataTable
        data={data}
        reportType={reportType}
        onDelete={handleDeleteRecord}
        onEdit={handleEditRecord}
      />

      {isAddModalOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-purple-100">
            <div className="sticky top-0 bg-gradient-to-r from-purple-600 to-indigo-600 px-6 py-5 flex items-center justify-between">
              <h3 className="text-xl text-white font-bold">
                {editingRecord ? '✏️ Edit Record' : '➕ Add New Record'}
              </h3>
              <button
                onClick={() => {
                  setIsAddModalOpen(false);
                  setEditingRecord(null);
                  setNewRecord({});
                }}
                className="p-2 hover:bg-white/20 rounded-lg transition-colors"
              >
                <X className="size-5 text-white" />
              </button>
            </div>

            <div className="p-6">
              <div className="space-y-4">
                {columns.map((column) => (
                  <div key={column}>
                    <label className="block text-sm text-gray-700 mb-2 font-medium">
                      {formatColumnName(column)}
                    </label>
                    <input
                      type="text"
                      value={editingRecord ? editingRecord[column] || '' : newRecord[column] || ''}
                      onChange={(e) => {
                        if (editingRecord) {
                          setEditingRecord({ ...editingRecord, [column]: e.target.value });
                        } else {
                          setNewRecord({ ...newRecord, [column]: e.target.value });
                        }
                      }}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                      placeholder={`Enter ${formatColumnName(column)}`}
                    />
                  </div>
                ))}
              </div>

              <div className="mt-8 flex gap-3 justify-end">
                <button
                  onClick={() => {
                    setIsAddModalOpen(false);
                    setEditingRecord(null);
                    setNewRecord({});
                  }}
                  className="px-6 py-2.5 border-2 border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all font-medium"
                >
                  Cancel
                </button>
                <button
                  onClick={editingRecord ? handleUpdateRecord : handleAddRecord}
                  className="px-6 py-2.5 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-lg hover:from-purple-700 hover:to-indigo-700 transition-all font-medium shadow-lg"
                >
                  {editingRecord ? 'Update Record' : 'Add Record'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}