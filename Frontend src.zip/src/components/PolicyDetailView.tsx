import { useState, useRef, useEffect } from 'react';
import { Upload, File, X, CheckCircle2, AlertTriangle, AlertCircle, Hash, ChevronDown, ChevronUp } from 'lucide-react';
import { EmailReportSection } from './EmailReportSection';
import { uploadDocument, getRecordStats } from '../services/api';

interface PolicyDetailViewProps {
    policyType: string;
    variant?: 'admin' | 'user';
    externalContent?: string | null;
}

interface UploadedDocument {
    name: string;
    size: number;
    type: string;
    content: string;
}

interface ComplianceItem {
    rule: string;
    status: 'compliant' | 'non-compliant';
    description: string;
}

interface PolicyStatus {
    category: string;
    count: number;
    icon: 'active' | 'expiring' | 'validation' | 'expired';
    description: string;
    color: string;
}

export function PolicyDetailView({ policyType, variant = 'user', externalContent }: PolicyDetailViewProps) {
    const [uploadedDocument, setUploadedDocument] = useState<UploadedDocument | null>(null);
    const [isUploading, setIsUploading] = useState(false);
    const [isUploadSectionExpanded, setIsUploadSectionExpanded] = useState(true);
    const [stats, setStats] = useState<Record<string, number>>({});
    const fileInputRef = useRef<HTMLInputElement>(null);

    const fetchStats = async () => {
        try {
            const data = await getRecordStats('policy');
            setStats(data);
        } catch (error) {
            console.error('Failed to fetch stats:', error);
        }
    };

    useEffect(() => {
        fetchStats();
    }, []);

    // Sync with external content (e.g. from chatbot)
    useEffect(() => {
        if (externalContent) {
            setUploadedDocument({
                name: "Chat Attachment",
                size: externalContent.length,
                type: "text/plain",
                content: externalContent
            });
        }
    }, [externalContent]);

    const themeColors = variant === 'admin'
        ? { primary: 'purple', secondary: 'indigo' }
        : { primary: 'teal', secondary: 'blue' };

    // Analyze compliance based on content
    const analyzeCompliance = (content: string): ComplianceItem[] => {
        const compliance: ComplianceItem[] = [];

        // Check for key compliance indicators
        if (content.toLowerCase().includes('encryption') && content.toLowerCase().includes('aes-256')) {
            compliance.push({
                rule: 'Data Encryption Standards',
                status: 'compliant',
                description: 'Document specifies AES-256 encryption for data protection'
            });
        } else if (content.toLowerCase().includes('encryption')) {
            compliance.push({
                rule: 'Data Encryption Standards',
                status: 'non-compliant',
                description: 'Encryption mentioned but specific standards not defined'
            });
        }

        if (content.toLowerCase().includes('annual') && content.toLowerCase().includes('training')) {
            compliance.push({
                rule: 'Training Requirements',
                status: 'compliant',
                description: 'Annual training requirements are documented'
            });
        } else {
            compliance.push({
                rule: 'Training Requirements',
                status: 'non-compliant',
                description: 'Training requirements not clearly specified'
            });
        }

        if (content.toLowerCase().includes('incident') && content.toLowerCase().includes('24 hours')) {
            compliance.push({
                rule: 'Incident Reporting Timeline',
                status: 'compliant',
                description: 'Incident reporting within 24 hours is mandated'
            });
        } else if (content.toLowerCase().includes('incident')) {
            compliance.push({
                rule: 'Incident Reporting Timeline',
                status: 'non-compliant',
                description: 'Incident reporting timeline not specified'
            });
        }

        if (content.toLowerCase().includes('review') && (content.toLowerCase().includes('annual') || content.toLowerCase().includes('quarterly'))) {
            compliance.push({
                rule: 'Policy Review Frequency',
                status: 'compliant',
                description: 'Regular policy review schedule is defined'
            });
        } else {
            compliance.push({
                rule: 'Policy Review Frequency',
                status: 'non-compliant',
                description: 'Policy review schedule not specified'
            });
        }

        if (content.toLowerCase().includes('multi-factor') || content.toLowerCase().includes('mfa') || content.toLowerCase().includes('2fa')) {
            compliance.push({
                rule: 'Multi-Factor Authentication',
                status: 'compliant',
                description: 'Multi-factor authentication requirements documented'
            });
        } else {
            compliance.push({
                rule: 'Multi-Factor Authentication',
                status: 'non-compliant',
                description: 'Multi-factor authentication not mentioned'
            });
        }

        if (content.toLowerCase().includes('iso') || content.toLowerCase().includes('soc 2') || content.toLowerCase().includes('gdpr')) {
            compliance.push({
                rule: 'Regulatory Compliance Standards',
                status: 'compliant',
                description: 'Industry standard compliance frameworks referenced'
            });
        } else {
            compliance.push({
                rule: 'Regulatory Compliance Standards',
                status: 'non-compliant',
                description: 'No reference to industry compliance standards'
            });
        }

        return compliance;
    };

    // Generate policy status data based on real stats from backend
    const getPolicyStatusData = (): PolicyStatus[] => {
        // Map backend statuses to UI categories
        // Backend statuses found in sample data: "Active"
        // UI expects: "Active Policies", "Expiring Soon", "Need Validation", "Recently Expired"

        const activeCount = (stats['Active'] || 0) + (stats['Active Policies'] || 0);
        const expiringCount = (stats['Expiring Soon'] || 0);
        const validationCount = (stats['Need Validation'] || 0) + (stats['Approved'] || 0); // Mapping approved to validation if appropriate
        const expiredCount = (stats['Recently Expired'] || 0) + (stats['Expired'] || 0);

        return [
            {
                category: 'Active Policies',
                count: activeCount,
                icon: 'active',
                description: 'Do not need attention',
                color: 'green'
            },
            {
                category: 'Expiring Soon',
                count: expiringCount,
                icon: 'expiring',
                description: 'Re-Request required',
                color: 'red'
            },
            {
                category: 'Need Validation',
                count: validationCount,
                icon: 'validation',
                description: 'Validation required',
                color: 'yellow'
            },
            {
                category: 'Recently Expired',
                count: expiredCount,
                icon: 'expired',
                description: 'Assign Responsibilities',
                color: 'orange'
            }
        ];
    };

    const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            setIsUploading(true);

            try {
                // Use the real API service to upload and extract content
                const result = await uploadDocument(file, policyType);

                setUploadedDocument({
                    name: file.name,
                    size: file.size,
                    type: file.type,
                    content: result.full_text || "No readable content extracted."
                });
                setIsUploading(false);

                // Refresh stats
                fetchStats();

                // Keep section expanded if we have content
                setIsUploadSectionExpanded(true);
            } catch (error) {
                console.error('Error uploading/reading file:', error);
                alert("Failed to extract document content. Please ensure backend is running.");
                setIsUploading(false);
            }
        }
    };

    const formatFileSize = (bytes: number) => {
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
        return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
    };

    const complianceData = uploadedDocument ? analyzeCompliance(uploadedDocument.content) : [];
    const compliantCount = complianceData.filter(item => item.status === 'compliant').length;
    const nonCompliantCount = complianceData.filter(item => item.status === 'non-compliant').length;
    const policyStatusData = getPolicyStatusData();

    const IconComponent = ({ type }: { type: 'active' | 'expiring' | 'validation' | 'expired' }) => {
        switch (type) {
            case 'active':
                return <CheckCircle2 className="size-6 text-green-600" />;
            case 'expiring':
                return <X className="size-6 text-red-600" />;
            case 'validation':
                return <AlertTriangle className="size-6 text-yellow-600" />;
            case 'expired':
                return <Hash className="size-6 text-orange-600" />;
        }
    };

    const getColorClasses = (color: string) => {
        switch (color) {
            case 'green':
                return { bg: 'bg-green-100', text: 'text-green-700', hover: 'hover:bg-green-200' };
            case 'red':
                return { bg: 'bg-red-100', text: 'text-red-700', hover: 'hover:bg-red-200' };
            case 'yellow':
                return { bg: 'bg-yellow-100', text: 'text-yellow-700', hover: 'hover:bg-yellow-200' };
            case 'orange':
                return { bg: 'bg-orange-100', text: 'text-orange-700', hover: 'hover:bg-orange-200' };
            default:
                return { bg: 'bg-gray-100', text: 'text-gray-700', hover: 'hover:bg-gray-200' };
        }
    };

    const getPrimaryGradient = () => variant === 'admin' ? 'from-purple-100 to-indigo-100' : 'from-teal-100 to-blue-100';
    const getTextColor = () => variant === 'admin' ? 'text-purple-600' : 'text-teal-600';
    const getBgColor = () => variant === 'admin' ? 'bg-purple-600' : 'bg-teal-600';
    const getBorderColor = () => variant === 'admin' ? 'border-purple-200' : 'border-teal-200';
    const getBorder2Color = () => variant === 'admin' ? 'border-purple-100' : 'border-teal-100';
    const getGradientFrom = () => variant === 'admin' ? 'from-purple-50' : 'from-teal-50';
    const getGradientTo = () => variant === 'admin' ? 'to-indigo-50' : 'to-blue-50';
    const getTextGradient = () => variant === 'admin' ? 'from-purple-600 to-indigo-600' : 'from-teal-600 to-blue-600';
    const getTextPrimary = () => variant === 'admin' ? 'text-purple-700' : 'text-teal-700';
    const getTextSecondary = () => variant === 'admin' ? 'text-purple-600' : 'text-teal-600';
    const getSpinColor = () => variant === 'admin' ? 'border-purple-600' : 'border-teal-600';
    const getHoverBorderColor = () => variant === 'admin' ? 'hover:border-purple-500' : 'hover:border-teal-500';
    const getHoverBgColor = () => variant === 'admin' ? 'hover:bg-purple-50/50' : 'hover:bg-teal-50/50';

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center gap-3">
                <div className={`p-3 bg-gradient-to-r ${getPrimaryGradient()} rounded-xl`}>
                    <File className={`size-6 ${getTextColor()}`} />
                </div>
                <div>
                    <h2 className={`text-2xl font-bold bg-gradient-to-r ${getTextGradient()} bg-clip-text text-transparent`}>
                        {policyType}
                    </h2>
                    <p className="text-gray-600 text-sm">Upload and analyze policy documents</p>
                </div>
            </div>

            {/* Document Content Display - MOVED UP below Header */}
            {uploadedDocument && (
                <div className="animate-in fade-in slide-in-from-top-4 duration-500 space-y-6">
                    <div className="bg-white rounded-xl border-2 border-gray-200 shadow-md overflow-hidden">
                        <div className={`px-5 py-4 bg-gradient-to-r ${getGradientFrom()} ${getGradientTo()} border-b-2 ${getBorder2Color()}`}>
                            <h3 className={`font-bold ${getTextPrimary()} flex items-center gap-2`}>
                                <File className="size-5" />
                                Document Content
                            </h3>
                            <p className={`text-xs ${getTextSecondary()} mt-1`}>Analysis for: {uploadedDocument.name}</p>
                        </div>
                        <div className="p-5 bg-gray-50 border-b border-gray-200">
                            <textarea
                                readOnly
                                value={uploadedDocument.content}
                                className="w-full h-96 p-6 rounded-lg bg-white border border-gray-300 font-mono text-sm leading-relaxed focus:outline-none resize-none shadow-inner text-gray-800 scrollbar-thin scrollbar-thumb-teal-500 scrollbar-track-teal-100"
                                placeholder="Extracted document content will appear here..."
                            />
                        </div>
                    </div>

                    {/* Compliance and Non-Compliance Section */}
                    <div className="bg-white rounded-xl border-2 border-gray-200 shadow-md overflow-hidden">
                        <div className={`px-5 py-4 bg-gradient-to-r ${getGradientFrom()} ${getGradientTo()} border-b-2 ${getBorder2Color()}`}>
                            <h3 className={`font-bold ${getTextPrimary()} flex items-center gap-2`}>
                                <AlertCircle className="size-5" />
                                Compliance Analysis
                            </h3>
                            <p className={`text-xs ${getTextSecondary()} mt-1`}>
                                Based on document content - {compliantCount} compliant, {nonCompliantCount} non-compliant
                            </p>
                        </div>
                        <div className="p-5">
                            <div className="grid md:grid-cols-2 gap-6">
                                {/* Compliant Items */}
                                <div className="space-y-3">
                                    <div className="flex items-center gap-2 mb-3 px-1">
                                        <div className="p-1.5 bg-green-100 rounded-full">
                                            <CheckCircle2 className="size-5 text-green-600" />
                                        </div>
                                        <h4 className="font-bold text-green-700">Compliant ({compliantCount})</h4>
                                    </div>
                                    {complianceData.filter(item => item.status === 'compliant').map((item, index) => (
                                        <div key={index} className="bg-green-50/50 border border-green-100 border-l-4 border-l-green-500 rounded-lg p-4 shadow-sm">
                                            <p className="font-bold text-green-800 text-sm">{item.rule}</p>
                                            <p className="text-xs text-green-600 mt-1">{item.description}</p>
                                        </div>
                                    ))}
                                </div>

                                {/* Non-Compliant Items */}
                                <div className="space-y-3">
                                    <div className="flex items-center gap-2 mb-3 px-1">
                                        <div className="p-1.5 bg-red-100 rounded-full">
                                            <AlertTriangle className="size-5 text-red-600" />
                                        </div>
                                        <h4 className="font-bold text-red-700">Non-Compliant ({nonCompliantCount})</h4>
                                    </div>
                                    {complianceData.filter(item => item.status === 'non-compliant').map((item, index) => (
                                        <div key={index} className="bg-red-50/50 border border-red-100 border-l-4 border-l-red-500 rounded-lg p-4 shadow-sm">
                                            <p className="font-bold text-red-800 text-sm">{item.rule}</p>
                                            <p className="text-xs text-red-600 mt-1">{item.description}</p>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* Upload Section - Collapsible */}
            <div className={`border-2 ${getBorderColor()} rounded-xl overflow-hidden bg-white shadow-md`}>
                <button
                    onClick={() => setIsUploadSectionExpanded(!isUploadSectionExpanded)}
                    className={`w-full flex items-center justify-between px-5 py-4 bg-gradient-to-r ${getGradientFrom()} ${getGradientTo()} hover:${getGradientFrom().replace('from-', 'from-').replace('-50', '-100')} hover:${getGradientTo().replace('to-', 'to-').replace('-50', '-100')} transition-all`}
                >
                    <div className="flex items-center gap-3">
                        <div className={`p-2 ${getBgColor()} rounded-lg`}>
                            <Upload className="size-5 text-white" />
                        </div>
                        <div className="text-left">
                            <h3 className={`font-bold ${getTextPrimary()}`}>Upload Policy Document</h3>
                            <p className={`text-xs ${getTextSecondary()}`}>PDF, Word, CSV, or Excel files</p>
                        </div>
                    </div>
                    {isUploadSectionExpanded ? (
                        <ChevronUp className={`size-5 ${getTextSecondary()}`} />
                    ) : (
                        <ChevronDown className={`size-5 ${getTextSecondary()}`} />
                    )}
                </button>

                {isUploadSectionExpanded && (
                    <div className={`p-5 border-t-2 ${getBorder2Color()}`}>
                        <input
                            type="file"
                            ref={fileInputRef}
                            onChange={handleFileSelect}
                            accept=".pdf,.doc,.docx,.csv,.xls,.xlsx"
                            className="hidden"
                        />

                        <div
                            onClick={() => fileInputRef.current?.click()}
                            className={`border-2 border-dashed ${getBorderColor()} rounded-xl p-8 text-center cursor-pointer ${getHoverBorderColor()} ${getHoverBgColor()} transition-all`}
                        >
                            <div className="flex flex-col items-center gap-3">
                                <div className={`p-4 bg-gradient-to-r ${getPrimaryGradient()} rounded-full`}>
                                    <Upload className={`size-8 ${getTextColor()}`} />
                                </div>
                                <div>
                                    <p className="font-semibold text-gray-700">Click to upload policy document</p>
                                    <p className="text-sm text-gray-500 mt-1">or drag and drop file here</p>
                                </div>
                                <p className="text-xs text-gray-400">Supported: PDF, DOC, DOCX, CSV, XLS, XLSX</p>
                            </div>
                        </div>

                        {isUploading && (
                            <div className="mt-4 flex items-center justify-center gap-3 text-gray-600">
                                <div className={`size-5 border-2 ${getSpinColor()} border-t-transparent rounded-full animate-spin`} />
                                <span>Processing document...</span>
                            </div>
                        )}

                        {uploadedDocument && !isUploading && (
                            <div className={`mt-4 flex items-center justify-between bg-gradient-to-r ${getGradientFrom()} ${getGradientTo()} rounded-lg px-4 py-3 border ${getBorderColor()}`}>
                                <div className="flex items-center gap-3">
                                    <File className={`size-5 ${getTextColor()}`} />
                                    <div>
                                        <p className="text-sm font-medium text-gray-700">{uploadedDocument.name}</p>
                                        <p className="text-xs text-gray-500">{formatFileSize(uploadedDocument.size)}</p>
                                    </div>
                                </div>
                                <button
                                    onClick={() => setUploadedDocument(null)}
                                    className="p-1.5 hover:bg-red-100 rounded-lg transition-colors"
                                >
                                    <X className="size-4 text-red-500" />
                                </button>
                            </div>
                        )}
                    </div>
                )}
            </div>

            {/* Policy Status Table */}
            <div className="bg-white rounded-xl border-2 border-gray-200 shadow-md overflow-hidden">
                <div className={`px-5 py-4 bg-gradient-to-r ${getGradientFrom()} ${getGradientTo()} border-b-2 ${getBorder2Color()}`}>
                    <h3 className={`font-bold ${getTextPrimary()} flex items-center gap-2`}>
                        <AlertCircle className="size-5" />
                        Policy Status Report
                    </h3>
                    <p className={`text-xs ${getTextSecondary()} mt-1`}>Overview of all {policyType.toLowerCase()} status</p>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full">
                        <thead className="bg-gray-100 border-b-2 border-gray-200">
                            <tr>
                                <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Status</th>
                                <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Count</th>
                                <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Description</th>
                                <th className="px-6 py-4 text-left text-sm font-bold text-gray-700">Action Required</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                            {policyStatusData.map((status, index) => {
                                const colorClasses = getColorClasses(status.color);
                                return (
                                    <tr key={index} className="hover:bg-gray-50 transition-colors">
                                        <td className="px-6 py-4">
                                            <div className="flex items-center gap-3">
                                                <IconComponent type={status.icon} />
                                                <span className="font-semibold text-gray-800">{status.category}</span>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4">
                                            <div className={`inline-flex items-center justify-center min-w-[40px] px-3 py-1.5 rounded-full font-bold text-sm ${colorClasses.bg} ${colorClasses.text}`}>
                                                {status.count}
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 text-gray-600 text-sm">{status.description}</td>
                                        <td className="px-6 py-4">
                                            <button className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${colorClasses.bg} ${colorClasses.text} ${colorClasses.hover}`}>
                                                View Details
                                            </button>
                                        </td>
                                    </tr>
                                );
                            })}
                        </tbody>
                    </table>
                </div>

                {/* Summary Footer */}
                <div className={`px-5 py-4 bg-gradient-to-r ${getGradientFrom()} ${getGradientTo()} border-t-2 ${getBorder2Color()}`}>
                    <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">
                            Total Policies: <span className="font-bold text-gray-800">{policyStatusData.reduce((sum, item) => sum + item.count, 0)}</span>
                        </span>
                        <span className="text-gray-600">
                            Requiring Attention: <span className="font-bold text-red-600">
                                {policyStatusData.filter(s => s.icon !== 'active').reduce((sum, item) => sum + item.count, 0)}
                            </span>
                        </span>
                    </div>
                </div>
            </div>

            {/* Email Report Section */}
            <EmailReportSection category={policyType} variant={variant} />
        </div>
    );
}