import { useState, useMemo } from 'react';
import { ChevronUp, ChevronDown, Search, Edit2, Trash2 } from 'lucide-react';

interface DataTableProps {
  data: any[];
  reportType: string;
  onDelete?: (index: number) => void;
  onEdit?: (index: number) => void;
  variant?: 'purple' | 'teal';
}

export function DataTable({ data, reportType, onDelete, onEdit, variant = 'purple' }: DataTableProps) {
  const [currentPage, setCurrentPage] = useState(1);
  const [sortColumn, setSortColumn] = useState<string | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [searchTerm, setSearchTerm] = useState('');
  const itemsPerPage = 10;

  const theme = {
    purple: {
      primary: 'purple',
      secondary: 'indigo',
      text: 'text-purple-700',
      textLight: 'text-purple-400',
      textStrong: 'text-purple-600',
      border: 'border-purple-200',
      borderLight: 'border-purple-100',
      bg: 'bg-purple-600',
      bgLight: 'from-purple-50 to-indigo-50',
      bgHover: 'hover:bg-purple-100',
      bgHoverLight: 'hover:bg-purple-50',
      ring: 'focus:ring-purple-500',
      focusBorder: 'focus:border-purple-500',
      paginationActive: 'bg-gradient-to-r from-purple-600 to-indigo-600'
    },
    teal: {
      primary: 'teal',
      secondary: 'blue',
      text: 'text-teal-700',
      textLight: 'text-teal-400',
      textStrong: 'text-teal-600',
      border: 'border-teal-200',
      borderLight: 'border-teal-100',
      bg: 'bg-teal-600',
      bgLight: 'from-teal-50 to-blue-50',
      bgHover: 'hover:bg-teal-100',
      bgHoverLight: 'hover:bg-teal-50',
      ring: 'focus:ring-teal-500',
      focusBorder: 'focus:border-teal-500',
      paginationActive: 'bg-gradient-to-r from-teal-600 to-blue-600'
    }
  }[variant];

  // Get columns from data
  const columns = data.length > 0 ? Object.keys(data[0]) : [];

  // Filter data based on search
  const filteredData = useMemo(() => {
    if (!searchTerm) return data;

    return data.filter((row) =>
      Object.values(row).some((value) =>
        String(value).toLowerCase().includes(searchTerm.toLowerCase())
      )
    );
  }, [data, searchTerm]);

  // Sort data
  const sortedData = useMemo(() => {
    if (!sortColumn) return filteredData;

    return [...filteredData].sort((a, b) => {
      const aVal = a[sortColumn];
      const bVal = b[sortColumn];

      if (aVal < bVal) return sortDirection === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  }, [filteredData, sortColumn, sortDirection]);

  // Paginate data
  const paginatedData = useMemo(() => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    return sortedData.slice(startIndex, startIndex + itemsPerPage);
  }, [sortedData, currentPage]);

  const totalPages = Math.ceil(sortedData.length / itemsPerPage);

  const handleSort = (column: string) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(column);
      setSortDirection('asc');
    }
  };

  const formatColumnName = (column: string) => {
    return column
      .replace(/([A-Z])/g, ' $1')
      .replace(/^./, (str) => str.toUpperCase())
      .trim();
  };

  return (
    <div className="space-y-4">
      {/* Search Bar */}
      <div className="relative">
        <Search className={`absolute left-3 top-1/2 transform -translate-y-1/2 ${theme.textLight} size-5`} />
        <input
          type="text"
          placeholder="Search across all columns..."
          value={searchTerm}
          onChange={(e) => {
            setSearchTerm(e.target.value);
            setCurrentPage(1);
          }}
          className={`w-full pl-10 pr-4 py-3 border-2 ${theme.border} rounded-lg focus:outline-none focus:ring-2 ${theme.ring} ${theme.focusBorder} transition-all`}
        />
      </div>

      {/* Table */}
      <div className={`overflow-x-auto border-2 ${theme.borderLight} rounded-xl shadow-lg`}>
        <table className={`min-w-full divide-y ${theme.borderLight}`}>
          <thead className={theme.bgLight}>
            <tr>
              {columns.map((column) => (
                <th
                  key={column}
                  onClick={() => handleSort(column)}
                  className={`px-6 py-4 text-left text-xs ${theme.text} uppercase tracking-wider cursor-pointer ${theme.bgHover} transition-colors font-bold`}
                >
                  <div className="flex items-center gap-2">
                    {formatColumnName(column)}
                    <div className="flex flex-col">
                      <ChevronUp
                        className={`size-3 ${sortColumn === column && sortDirection === 'asc'
                            ? theme.textStrong
                            : 'text-gray-400'
                          }`}
                      />
                      <ChevronDown
                        className={`size-3 -mt-1 ${sortColumn === column && sortDirection === 'desc'
                            ? theme.textStrong
                            : 'text-gray-400'
                          }`}
                      />
                    </div>
                  </div>
                </th>
              ))}
              {(onEdit || onDelete) && (
                <th className={`px-6 py-4 text-left text-xs ${theme.text} uppercase tracking-wider font-bold`}>
                  Actions
                </th>
              )}
            </tr>
          </thead>
          <tbody className={`bg-white divide-y ${theme.borderLight.replace('border-', 'divide-')}`}>
            {paginatedData.length > 0 ? (
              paginatedData.map((row, rowIndex) => {
                const actualIndex = (currentPage - 1) * itemsPerPage + rowIndex;
                return (
                  <tr key={rowIndex} className={`${theme.bgHoverLight} transition-colors`}>
                    {columns.map((column) => (
                      <td key={column} className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        {row[column]}
                      </td>
                    ))}
                    {(onEdit || onDelete) && (
                      <td className="px-6 py-4 whitespace-nowrap text-sm">
                        <div className="flex items-center gap-2">
                          {onEdit && (
                            <button
                              onClick={() => onEdit(actualIndex)}
                              className={`p-2 hover:bg-${theme.secondary}-100 rounded-lg transition-colors group`}
                              title="Edit"
                            >
                              <Edit2 className={`size-4 text-${theme.secondary}-600 group-hover:scale-110 transition-transform`} />
                            </button>
                          )}
                          {onDelete && (
                            <button
                              onClick={() => onDelete(actualIndex)}
                              className="p-2 hover:bg-red-100 rounded-lg transition-colors group"
                              title="Delete"
                            >
                              <Trash2 className="size-4 text-red-600 group-hover:scale-110 transition-transform" />
                            </button>
                          )}
                        </div>
                      </td>
                    )}
                  </tr>
                );
              })
            ) : (
              <tr>
                <td colSpan={columns.length + (onEdit || onDelete ? 1 : 0)} className="px-6 py-12 text-center text-gray-500">
                  <div className="flex flex-col items-center">
                    <Search className="size-12 text-gray-300 mb-3" />
                    <p className="text-lg">No data found</p>
                    <p className="text-sm text-gray-400 mt-1">Try adjusting your search criteria</p>
                  </div>
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className={`flex items-center justify-between bg-white p-4 rounded-lg border ${theme.borderLight}`}>
          <p className="text-sm text-gray-700">
            Showing <span className={`font-semibold ${theme.textStrong}`}>{(currentPage - 1) * itemsPerPage + 1}</span> to{' '}
            <span className={`font-semibold ${theme.textStrong}`}>{Math.min(currentPage * itemsPerPage, sortedData.length)}</span> of{' '}
            <span className={`font-semibold ${theme.textStrong}`}>{sortedData.length}</span> results
          </p>
          <div className="flex gap-2">
            <button
              onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
              className={`px-4 py-2 border-2 border-${theme.primary}-300 ${theme.text} rounded-lg ${theme.bgHoverLight} disabled:opacity-50 disabled:cursor-not-allowed transition-all font-medium`}
            >
              Previous
            </button>
            <div className="flex gap-1">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                <button
                  key={page}
                  onClick={() => setCurrentPage(page)}
                  className={`px-4 py-2 rounded-lg transition-all font-medium ${currentPage === page
                      ? `${theme.paginationActive} text-white shadow-lg`
                      : `border-2 ${theme.border} ${theme.text} ${theme.bgHoverLight}`
                    }`}
                >
                  {page}
                </button>
              ))}
            </div>
            <button
              onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages}
              className={`px-4 py-2 border-2 border-${theme.primary}-300 ${theme.text} rounded-lg ${theme.bgHoverLight} disabled:opacity-50 disabled:cursor-not-allowed transition-all font-medium`}
            >
              Next
            </button>
          </div>
        </div>
      )}
    </div>
  );
}