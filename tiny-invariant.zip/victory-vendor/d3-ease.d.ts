
// `victory-vendor/d3-ease` (TypeScript)
//
// Export the type definitions for this package:
export * from "d3-ease";
