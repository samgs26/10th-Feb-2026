"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.radians = exports.degrees = void 0;
const radians = Math.PI / 180;
exports.radians = radians;
const degrees = 180 / Math.PI;
exports.degrees = degrees;