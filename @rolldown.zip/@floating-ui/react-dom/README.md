# @floating-ui/react-dom

This is the library to use Floating UI with React DOM.
