# `react-primitive`

This is an internal utility, not intended for public usage.
