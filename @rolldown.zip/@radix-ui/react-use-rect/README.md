# `react-use-rect`

## Installation

```sh
$ yarn add @radix-ui/react-use-rect
# or
$ npm install @radix-ui/react-use-rect
```

## Usage

This is an internal utility, not intended for public usage.
